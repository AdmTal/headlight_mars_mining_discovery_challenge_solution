export const ACTIONS = {
    GOT_DATA: 'GOT_DATA',
};
